package com.sample.demoapp.web;

class HelloWorld {
	
	public static void main ( String [] args) {
		System.out.println ("Sample Demo Code");
	}
}